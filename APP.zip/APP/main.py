import requests
from pywebio import input, output, start_server

# РЕГИОНЫ
regions = {
    "Москва": 1,
    "Санкт-Петербург": 2,
    "Новосибирск": 4,
    "Екатеринбург": 3,
    "Нижний Новгород": 66,
    "Казань": 88,
    "Челябинск": 56,
     
